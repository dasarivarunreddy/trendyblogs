<?php

//loads required files
require "config.php";
require "connection.php";
require "functions.php";
