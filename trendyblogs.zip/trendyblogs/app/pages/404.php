<?php include '../app/pages/includes/header.php'; ?>

<center class="alert alert-danger"><h1>Page not found</h1></center>

<?php include '../app/pages/includes/footer.php'; ?>